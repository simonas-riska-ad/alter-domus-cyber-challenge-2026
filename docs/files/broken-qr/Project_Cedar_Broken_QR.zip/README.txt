PROJECT CEDAR — ONBOARDING QR RECOVERY

A QR code from a fictional onboarding packet was damaged during document processing.
Four image fragments were recovered.

Reconstruct the original QR code and scan it to recover the flag.

Notes:
- All challenge data is synthetic.
- No brute force is required.
- The fragments may need to be rotated as well as rearranged.
