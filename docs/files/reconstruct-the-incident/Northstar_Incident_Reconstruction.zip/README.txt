NORTHSTAR - INCIDENT RECONSTRUCTION PACKAGE

A fictional security team collected four data sources after suspicious activity was reported:

- authentication.log
- vpn_sessions.csv
- portal_access.log
- endpoint_events.csv

Reconstruct the incident and identify:
1. the affected user
2. the external source IP used for the unauthorized access
3. the sensitive file that was downloaded

Submit the flag as:
ADCTF{username_ip_filename}

Example:
ADCTF{alex.morgan_192.0.2.10_example.csv}

All identities, addresses, systems and records in this package are synthetic.
